Java binding for MediaInfo DLL/SO

Two alternatives are possible depends on which "binding interface" you desire:
- JNA     http://jna.dev.java.net
- JNAtive http://jnative.sourceforge.net